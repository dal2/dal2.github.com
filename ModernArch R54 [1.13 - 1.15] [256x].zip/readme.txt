All files in here are the property of MN3. They cannot be distributed without permission. 
More information can be found here: https://www.packminecraft.com/

​©2020 Pack Minecraft – All rights reserved. Minecraft is copyright of Mojang AB and is not afilliated with us.